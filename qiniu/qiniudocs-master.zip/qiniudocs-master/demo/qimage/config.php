<?php

class Config
{
    const 
        ACCESS_KEY = 'Access_Key',
        SECRET_KEY = 'Secret_Key',
        BUCKET_NAME = 'rwxf';
}
