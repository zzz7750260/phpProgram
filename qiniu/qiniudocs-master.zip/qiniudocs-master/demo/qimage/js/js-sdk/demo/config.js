module.exports = {
    'ACCESS_KEY': '<Your Access Key>',
    'SECRET_KEY': '<Your Secret Key>',
    'Bucket_Name': '<Your Bucket Name>',
    'Port': 19110,
    'Uptoken_Url': '/uptoken',
    'Domain': 'http://qiniu-plupload.qiniudn.com/'
};
