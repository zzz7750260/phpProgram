<?php

class Config
{
    const DB_NAME = 'qspace',
        DB_USER = 'root',
        DB_PWD = 'root',
        DB_HOST = '127.0.0.1',
        ACCESS_KEY = 'Access_Key',
        SECRET_KEY = 'Secret_Key',
        BUCKET_NAME = 'devtest';
}

