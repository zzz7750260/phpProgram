<?php

require_once 'vendor/autoload.php';

$smarty = new Smarty();	
$smarty->display('login.tpl');
