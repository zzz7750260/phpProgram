<?php
require_once 'config.php';

$uname = $_POST['uname'];
$_pwd = $_POST['pwd'];

