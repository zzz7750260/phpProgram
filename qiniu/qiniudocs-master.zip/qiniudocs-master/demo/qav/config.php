<?php

class Config 
{
    const DB_NAME = 'qav',
          DB_USER = 'root',
          DB_PWD = '',
          DB_HOST = '127.0.0.1',
          AK = 'Access_Key',
          SK = 'Secret_Key',

          BUCKET_NAME = 'devtest',
		  UPTOKEN_URL = 'uptoken.php',
		  DOMAIN = 'http://devtest.qiniudn.com/';
}

