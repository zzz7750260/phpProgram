
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","base64_urlSafeDecode()"],["f","base64_urlSafeEncode()"],["f","crc32_data()"],["f","crc32_file()"],["f","entry()"],["f","json_decode()"],["c","Qiniu\\Auth"],["c","Qiniu\\Config"],["c","Qiniu\\Etag"],["c","Qiniu\\Http\\Client"],["c","Qiniu\\Http\\Error"],["c","Qiniu\\Http\\Request"],["c","Qiniu\\Http\\Response"],["c","Qiniu\\Processing\\Operation"],["c","Qiniu\\Processing\\PersistentFop"],["c","Qiniu\\Storage\\BucketManager"],["c","Qiniu\\Storage\\FormUploader"],["c","Qiniu\\Storage\\ResumeUploader"],["c","Qiniu\\Storage\\UploadManager"]];
