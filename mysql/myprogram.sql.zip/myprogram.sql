-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 年 05 月 14 日 07:18
-- 服务器版本: 5.0.45
-- PHP 版本: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- 数据库: `myprogram`
--

-- --------------------------------------------------------

--
-- 表的结构 `article`
--

CREATE TABLE `article` (
  `aid` int(11) NOT NULL auto_increment COMMENT '文章的id',
  `title` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章的标题',
  `short_title` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章标题简写',
  `category_id` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章分类的id',
  `article_key` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章的关键词组',
  `article_short` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章的摘要',
  `article_author` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章的作者',
  `article_source` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章的来源',
  `article_commit` tinyint(4) NOT NULL COMMENT '文章是否允许评论',
  `commit_start` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '评论开始时间',
  `commit_end` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '评论结束时间',
  `article_img` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章封面的路劲',
  `article_container` text character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章内容',
  `article_status` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL default 'public' COMMENT '文章发布的状态',
  `commit_status` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '评论的状态',
  `article_sh` tinyint(4) NOT NULL default '0' COMMENT '文章的审核状态',
  PRIMARY KEY  (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- 导出表中的数据 `article`
--

INSERT INTO `article` (`aid`, `title`, `short_title`, `category_id`, `article_key`, `article_short`, `article_author`, `article_source`, `article_commit`, `commit_start`, `commit_end`, `article_img`, `article_container`, `article_status`, `commit_status`, `article_sh`) VALUES
(2, '网站后台', '网站后台', '3', '网站后台', '网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模', 'admin', 'admin', 0, '2018-04-11 18:02:39', '2018-05-12 18:02:41', '阿里旺旺图片20180330173650.jpg', '<p>网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模网站后台模版,后台模版下载,后台管理系统模版,HTML后台模</p>', 'false', 'true', 0),
(3, '啊大大', '网站后', '4', '阿达', '同时获取上传图片的名称同时获取上传图片的名称', 'admin', 'admin', 0, '2018-04-13 17:54:20', '2018-04-30 17:54:23', '相片1.jpg', '<p>同时获取上传图片的名称同时获取上传图片的名称同时获取上传图片的名称同时获取上传图片的名称同时获取上传图片的名称同时获取上传图片的名称同时获取上传图片的名称</p>', 'false', 'true', 0),
(7, '网站后台', '文档', '5', '文档', '网站后台网站后台网站后台网站后台', 'admin', 'admin', 0, '2018-04-13 18:21:55', '2018-05-12 18:21:56', '沈宏韬XY00051.jpg', '<p>网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台网站后台</p>', 'draft', 'true', 0),
(8, '文章状态', '状态', '2', '文章状态', '文章状态文章状态文章状态文章状态文章状态文章状态文章状态', 'cc5566', 'admin', 0, '2018-04-16 18:11:40', '2018-05-12 18:11:44', '沈宏韬XY00051.jpg', '<p>文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态</p>', 'draft', 'true', 0),
(9, '文章状态', '状态', '4', '文章状态', '文章状态文章状态文章状态文章状态文章状态文章状态文章状态', 'zzz7788', 'admin', 0, '2018-04-16 18:11:40', '2018-05-12 18:11:44', '沈宏韬XY00051.jpg', '<p>文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态文章状态</p>', 'draft', 'true', 0),
(10, '测试分类', '分类', '5', '测试分类', '测试分类测试分类测试分类测试分类测试分类测试分类', 'admin', 'admin', 0, '2018-04-17 14:20:45', '2018-05-12 14:20:47', '阿里旺旺图片20180330173650.jpg', '<p>测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类测试分类</p>', 'public', 'true', 0),
(11, '文章静态化', '文章', '2', '文章', '文章文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化', 'admin', 'admin', 0, '2018-04-25 13:50:13', '2018-05-12 13:50:16', 'ccc.png', '<p>文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化文章静态化</p>', 'public', 'true', 0),
(12, '添加测试5', '添加测试5', '5', '添加', '添加测试5添加测试5添加测试5添加测试5添加测试5', 'admin', 'admin', 0, '2018-05-07 17:05:29', '2018-05-31 17:05:31', '图片1.png', '<p>添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5添加测试5</p>', 'public', 'true', 0),
(13, '到ID哈搜狐1', '到ID哈搜狐1', '5', '到ID哈搜狐1', '到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1', 'admin', 'admin', 0, '2018-05-09 18:32:30', '2018-06-09 18:32:33', '图片1.png', '<p>到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1</p>', 'public', 'true', 0),
(14, '到ID哈搜狐1', '到ID哈搜狐1', '5', '到ID哈搜狐1', '到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1', 'admin', 'admin', 0, '2018-05-09 18:32:30', '2018-06-09 18:32:33', '图片1.png', '<p>到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1</p>', 'public', 'true', 0),
(15, '到ID哈搜阿达的', '到ID哈搜狐1', '5', '到ID哈搜狐1', '到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1', 'admin', 'admin', 0, '2018-05-09 18:32:30', '2018-06-09 18:32:33', '图片1.png', '<p>到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1到ID哈搜狐1</p>', 'public', 'true', 0),
(16, '上传图片', '图片', '5', '上传图片', '上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片', 'admin', 'admin', 0, '2018-05-10 13:04:02', '2018-06-09 13:04:04', 'ccc.png', '<p>上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片</p><p><img src="/ueditor/php/upload/image/20180510/1525927273270669.png" title="1525927273270669.png" alt="图片1.png"/></p>', 'public', 'true', 0),
(17, '上传图片aaaa', '图片', '5', '上传图片', '上传图片上传图片上传图片上传图片上传图片上传图片上传图片上传图片', 'admin', 'admin', 0, '2018-05-10 13:04:02', '2018-06-09 13:04:04', 'ccc.png', '<p>qqqqqqqqqqdasasa</p><p><img src="/ueditor/php/upload/image/20180510/1525939011226777.png" title="1525939011226777.png" alt="ccc.png"/></p>', 'public', 'true', 0),
(19, '图片上传展示', '图片', '5', '图片图', '图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示', 'admin', 'admin', 0, '2018-05-11 17:53:12', '2018-06-09 17:53:16', '图片1.png', '<p>图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示图片上传展示</p><p><img src="http://localhost/program/./upload/image/20180511/1526032425875567.png" title="1526032425875567.png" alt="ccc.png"/></p>', 'public', 'true', 0);

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE `category` (
  `cid` int(10) NOT NULL auto_increment COMMENT '分类的id',
  `cpid` int(10) NOT NULL default '0' COMMENT '分类的父类id',
  `categoryname` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '分类的名称',
  `categoryyw` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '分类的英文',
  `categoryms` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '分类的注析',
  PRIMARY KEY  (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- 导出表中的数据 `category`
--

INSERT INTO `category` (`cid`, `cpid`, `categoryname`, `categoryyw`, `categoryms`) VALUES
(1, 0, '音乐', 'music', '音乐的世界'),
(2, 0, '文章', 'article', '这个是文章分类'),
(3, 1, '古典音乐', 'oldmusic', '这个是古典音乐'),
(4, 1, '流行音乐', 'lxmusic', '这个是流行音乐'),
(5, 3, '子古典音乐', 'childoldmusic', '这个是子古典音乐');

-- --------------------------------------------------------

--
-- 表的结构 `member`
--

CREATE TABLE `member` (
  `id` int(10) NOT NULL auto_increment COMMENT '成员Id',
  `iid` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '成员编号',
  `username` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '成员用户名',
  `password` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '登录密码',
  `role` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `member`
--

INSERT INTO `member` (`id`, `iid`, `username`, `password`, `role`) VALUES
(1, '11', 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- 表的结构 `menu`
--

CREATE TABLE `menu` (
  `mid` int(10) NOT NULL auto_increment COMMENT '菜单的id',
  `mpid` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL default '0' COMMENT '菜单的父类id',
  `menuname` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '菜单的名称',
  `menurole` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL default 'admin' COMMENT '菜单的权限',
  `menuyw` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '菜单的英文',
  `menuurl` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '菜单的链接',
  PRIMARY KEY  (`mid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- 导出表中的数据 `menu`
--

INSERT INTO `menu` (`mid`, `mpid`, `menuname`, `menurole`, `menuyw`, `menuurl`) VALUES
(1, '0', '资源管理', 'admin', 'zy', ''),
(2, '1', '资讯管理', 'admin', 'zxgl', './article-list.html'),
(3, '1', '添加资讯', 'admin', 'addzx', './addzx.html'),
(4, '0', '图片管理', 'admin', 'picture', './thepicture'),
(8, '0', '系统管理', 'super,admi', 'xt', 'xt.html'),
(11, '0', '评论管理', 'admin,supe', 'pl', 'pl.html'),
(12, '0', '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `role`
--

CREATE TABLE `role` (
  `rid` int(3) NOT NULL auto_increment COMMENT '角色的id号',
  `rolename` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '角色名称',
  `roleyw` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '角色英文名称',
  `rolems` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '角色描述',
  `rolelmqx` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '角色栏目管理权限',
  `rolewzqx` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '文章管理权限',
  `roleyhqx` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT '用户管理权限',
  PRIMARY KEY  (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- 导出表中的数据 `role`
--

INSERT INTO `role` (`rid`, `rolename`, `roleyw`, `rolems`, `rolelmqx`, `rolewzqx`, `roleyhqx`) VALUES
(1, '超级', 'super', '阿达', 'Array', 'Array', 'Array'),
(2, '超级', 'super', '阿达', 'Array', 'Array', 'Array'),
(5, '超级管理员', 'admin', '拥有所有权限', 'lmadd,lmedit,lmdel,lmcheck,lmxz,', 'wzadd,wzedit,wzdel', 'yhadd,yhedit'),
(6, '编辑', 'edit', '主要负责编辑文章', 'lmcheck', 'wzadd,wzedit', 'yhcheck'),
(7, '编辑', 'edit', '主要负责编辑文章', 'lmcheck', 'wzadd,wzedit', 'yhcheck'),
(8, '超级编辑22', 'superedit', '拥有超级编辑管理权限', 'lmcheck', 'wzadd,wzedit,wzdel,wzcheck,wzxz', 'yhcheck');

-- --------------------------------------------------------

--
-- 表的结构 `web_info`
--

CREATE TABLE `web_info` (
  `web_name` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '网站的名称',
  `web_title` varchar(300) collate utf8_unicode_ci NOT NULL COMMENT '网站的title',
  `web_keyword` varchar(300) collate utf8_unicode_ci NOT NULL COMMENT '网站的关键词',
  `web_short` varchar(1000) collate utf8_unicode_ci NOT NULL COMMENT '网站的描述',
  `web_author` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '网站的作者',
  `web_record` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '网站的备案号',
  PRIMARY KEY  (`web_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 导出表中的数据 `web_info`
--

INSERT INTO `web_info` (`web_name`, `web_title`, `web_keyword`, `web_short`, `web_author`, `web_record`) VALUES
('课间十分钟', '快乐阅读-小视频-课间十分钟', '课间十分钟', '快乐阅读-小视频-课间十分钟快乐阅读-小视频-课间十分钟快乐阅读-小视频-课间十分钟快乐阅读-小视频-课间十分钟', 'admin', 'admin');
