-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018-08-26 10:56:15
-- 服务器版本: 5.5.56-MariaDB
-- PHP 版本: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `myprogram`
--

-- --------------------------------------------------------

--
-- 表的结构 `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `aid` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章的id',
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章的标题',
  `short_title` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章标题简写',
  `category_id` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章分类的id',
  `article_key` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章的关键词组',
  `article_short` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章的摘要',
  `article_cover` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章的选择封面',
  `article_author` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章的作者',
  `article_source` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章的来源',
  `article_commit` tinyint(4) NOT NULL COMMENT '文章是否允许评论',
  `commit_start` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '评论开始时间',
  `commit_end` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '评论结束时间',
  `article_time` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章生成或者最后编辑的时间',
  `article_img` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章封面的路劲',
  `video_platform` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none' COMMENT '视频来源的平台',
  `video_source` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '视频来源',
  `article_container` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章内容',
  `article_status` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'public' COMMENT '文章发布的状态',
  `commit_status` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '评论的状态',
  `article_sh` tinyint(4) NOT NULL DEFAULT '0' COMMENT '文章的审核状态',
  `article_view` int(11) NOT NULL DEFAULT '0' COMMENT '文章的浏览量',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- 转存表中的数据 `article`
--

INSERT INTO `article` (`aid`, `title`, `short_title`, `category_id`, `article_key`, `article_short`, `article_cover`, `article_author`, `article_source`, `article_commit`, `commit_start`, `commit_end`, `article_time`, `article_img`, `video_platform`, `video_source`, `article_container`, `article_status`, `commit_status`, `article_sh`, `article_view`) VALUES
(39, '十分钟带你看完《诡新娘》', '唐唐说电影：最致命的女人，妙龄少女专克土豪，英雄救美后别总想', '7', '诡新娘，唐唐说电影，电影解说视频，', '最致命的女人，妙龄少女专克土豪，英雄救美后别总想得寸进尺！真的会出事！下面由课间十分钟带大家一起观看唐唐说电影中的《诡新娘》', '唐唐说电影', 'bigsmile', 'admin', 0, '2018-08-23 17:40:37', '2021-12-23 17:40:43', '2018-08-26', 'f08e6429d5e22391b6dae6a105c9d86ef6b511f6.jpg', 'bilibili', '//player.bilibili.com/player.html?aid=29578199&cid=51438630&page=1', '<p>　　最致命的女人，妙龄少女专克土豪，英雄救美后别总想得寸进尺!真的会出事!下面由课间十分钟带大家一起观看唐唐说电影中的《诡新娘》</p><p><br/></p><h3>　　电影介绍：</h3><p>　　《诡新娘》是由北京光影奇迹影视文化有限公司出品，苏菲、刘骐、陈国良、杨济妤等联袂主演的3D惊悚题材影片。诡新娘讲述清末民国初期安徽一大户人家留学海外的少爷因姐夫暴毙火速赶回家奔丧，夜里在回家路上于树林中搭救一姑娘，该女子名为丽娘，少爷与丽娘日久生情，大婚之夜，丽娘被一老鬼鬼上身。据悉，电影诡新娘将于2016年8月26日上映。</p><p><br/></p><h3>　　剧情介绍：</h3><p>　　自沈府三少爷出生以来，天下人民百姓过得很幸福，然危难却总在安详的时候来到。沈家名门的先祖，曾于深山之中发现了一巨大石窟，窟内有着一块刻着难以辨认的古字的石头，而石头上的文字经解读后，竟刻满了沈府建成以来的大小事迹，何人将称大少爷，沈府以后会发生哪些重大事件，竟尽在此碑上早有预言。虽未知此碑由何人所立，但预言却一一应验，而最令人心惊肉跳的，就是碑文最后的一段，亦是预言的终结—当星空异象异象出现之时，七世怨侣现世，厉鬼将凭七世怨侣的力量而得天下，沈府从此化作无间地狱。年青有为的沈孝佑，作为沈家三少爷，在厉鬼出现时，先一步夺得先机，以免落在妖邪手中。果然，当仁九等鬼找到刚出生的七世怨侣的同时，统领魔道的‘阴月皇朝’，在魔君六道的带领下大举来犯，抢夺七世怨侣，一切就如神秘石碑所言一样。沈孝佑及丽娘这对斗气冤家，尽展平生所学和六道大战起来，结果正邪两道皆死伤枕藉，可是，虽然重创了魔君六道，但七世怨侣中的女婴还是被魔君六道夺去。自沈府三少爷出生以来，天下人民百姓过得很幸福，然危难却总在安详的时候来到。沈家名门的先祖，曾于深山之中发现了一巨大石窟，窟内有着一块刻着难以辨认的古字的石头，而石头上的文字经解读后，竟刻满了沈府建成以来的大小事迹，何人将称大少爷，沈府以后会发生哪些重大事件，竟尽在此碑上早有预言。虽未知此碑由何人所立，但预言却一一应验，而最令人心惊肉跳的，就是碑文最后的一段，亦是预言的终结—当星空异象异象出现之时，七世怨侣现世，厉鬼将凭七世怨侣的力量而得天下，沈府从此化作无间地狱。年青有为的沈孝佑，作为沈家三少爷，在厉鬼出现时，先一步夺得先机，以免落在妖邪手中。果然，当仁九等鬼找到刚出生的七世怨侣的同时，统领魔道的‘阴月皇朝’，在魔君六道的带领下大举来犯，抢夺七世怨侣，一切就如神秘石碑所言一样。沈孝佑及丽娘这对斗气冤家，尽展平生所学和六道大战起来，结果正邪两道皆死伤枕藉，可是，虽然重创了魔君六道，但七世怨侣中的女婴还是被魔君六道夺去。</p><p><br/></p><h3>　　剧情点评：</h3><p>　　其实解放后的人不能成精，所以民国或者晚晴成为了时空设定的首选。这部《诡新娘》也不例外，从全片的故事情节来看，其实在乡土情怀颇重的中国，特殊时期对于封建迷信的崇拜，造成了对于信仰、名利、情欲的畸形变奏，一方面是因为愚昧与盲从，比如管家与奴婢，一方面是因为心中的蝇营狗苟，比如老爷和奶奶。</p><p>　　但是总会有新的势力向传统势力宣战，从这意义上讲，男主人公作为新时期的青年，其实在努力尝试在孝道与自由恋爱中寻求到平衡，这当然是一种中间骑墙派的路线。但是，资产阶级的软弱性与妥协性，决定了悲剧的诞生。而代表革命性的农民阶级，一个是被卖入戏班的下九流女主，一个是隐姓埋名欺世盗名的道士男二，抱着某种为主报仇的狭隘执法思路，却选择了腹黑仙人跳的战斗格局，最后其实还是在路线上分道扬镳。</p><p>　　简单粗暴的恩仇逻辑，无法掩盖非正义的毒树之果，这大概就是影片所传递的主题思想吧。客观而言，本片囿于成本，在置景、道具，特别是特效方面还是稍显稚嫩，而拍摄手法与光线音效等方面又有电视剧的痕迹，叙事语言与整体节奏把控略显拖沓，在矛盾冲突不够挑起观众兴致的前提下，对于男主的演技、女主的颜值的确是颇具风险的考验。</p><p>　　庆幸的是，在片尾的二次翻转，将全场的舒缓陡然一紧，提速之后的情节发展与内心绵延，总算给出了有缺憾但应景的答案。真心为导演和编剧擦了一把汗。</p><p>　　事实上，这部《诡新娘》并非最新的作品，而是压了20个月，因为对于400万的小成本制作，其实能够有大荧幕放映的机会并不容易，那些大片盘剥之下，其实很多有诚意的小成本影片，并不能获得进场的机会，而这种恶性循环其实并不利于中国电影的发展。就拿恐怖片这个类型来说，如果在香港没有44年的积累，怎么会僵尸道长林正英这样经典形象?没错，任何一种类型片都需要有足够的量的积累才会有质的突破。假如连排片率都不能保证，那么总想中国电影冲奥获奖不就是天方奇谭?当然，你可以说网剧、网大甚至戏剧可以作为第二落点，提供更多试水的机会，比如《老男孩》、《夏洛特烦恼》，但是真正在大屏幕积累经验才是正道，才能真正对行业产生贡献。</p><p>　　为什么中国拍不出优秀的鬼片：导演李纪正在采访时说道：“我国是无神论国家，那么现代内容的影片是不可以有真鬼的，那么为了达到惊悚与恐怖的效果同时又要符合电影审查制度，编剧们只能打擦边球，于是乎，你看到的国产恐怖片和惊悚片，纵使通篇有神有鬼有僵尸有怨灵，但在结尾只能将这些恐怖情节解释为是做梦、幻象、精神分裂、服用了制幻药、有人恶作剧等等。瞬间逼格降低，观众大呼不爽……编剧们不是写不好，而是没法写……当然，可以拍古装的，古装的可以有神鬼，但是又会遭遇另外的问题，就是这些年，从《英雄》开始，国产电影市场有了一个独立的类别，也就是所为的“古装大片”，它们可能是各种题材，各种形式的，但是统一的特征就是古装、明星阵容强大、投资大。而恐怖片惊悚片其实不是面向大众的，观众群其实比较小，票房收益也普遍不高，所以投资方也没人敢作太大投入，这就产生了一个极度矛盾的局面，就是拍古装片本身投入就会大一些，影片的盈利风险变大了，同时又会让观众误认为是“古装大片”，直接与高投入的大片在市场上正面冲撞，进一步加大了风险。”</p><p><br/></p>', 'public', 'true', 0, 14),
(40, '十分钟带你看完《二流警探》', '唐唐说电影：最霸道的前女友 爆笑吐槽美国猛片', '7', '二流警探，二流警探解说，二流警探影评，唐唐说电影，课间十分钟', '《二线警探》是由哥伦比亚影片公司出品,影片于2010年8月6日在美国上映,下面由唐唐说电影来对这部电影进行影评，解说吧！', '唐唐说电影', 'bigsmile', 'bigsmile', 0, '2018-08-26 16:36:18', '2021-10-26 16:36:26', '2018-08-26', '8e112b6fcbf4da59cd36b451318ed0465c9a458f.jpg', 'bilibili', '//player.bilibili.com/player.html?aid=30175740&cid=52615653&page=1', '<p>　　《二线警探》是由哥伦比亚影片公司出品,影片于2010年8月6日在美国上映,下面由唐唐说电影来对这部电影进行影评，解说吧</p><p><br/></p><h3>　　电影介绍</h3><p>　　《二线警探》是由哥伦比亚影片公司出品，由亚当·麦凯执导，威尔·法瑞尔、马克·沃尔伯格、伊娃·门德斯联合主演的动作喜剧片，影片于2010年8月6日在美国上映 \n。</p><p><br/></p><h3>　　剧情介绍</h3><p>　　作为纽约警察局的超级巨星，克里斯托夫·丹森(道恩·强森饰)和P·K·海史密斯(塞缪尔·杰克逊饰)是整个纽约市最凶狠也最受人爱戴的警察，他们已然成为了偶像级别的人物，人们甚至争相在自己的身上文上他们的肖像或名字。距离他们的办公桌不远的地方坐着另外两位警探艾伦·盖姆伯尔(威尔·法瑞尔饰)和特里·霍兹(马克·沃尔伯格饰)，都是不折不扣的小角色，只能给他们那两位神勇的同事当陪衬，一般会在丹森和海史密斯的照片的不起眼的背景处发现他们，他们不是英雄，只不过是“二流警探”。</p><p>　　但是，再微不足道的警察也有可能迎来属于他们的辉煌，没过多久，盖姆伯尔和霍兹无意中卷入了一起看似无伤大雅的小案子中，甚至除了他们没有别的警察愿意接手，最终却演变成了纽约市有史以来最大、最轰动的罪案，对于他们来说，这无疑是一个好机会，但是盖姆伯尔和霍兹是否能够胜任这份工作</p><p><br/></p><h3>　　幕后花絮</h3><p>　　由巨石强森、威尔·法瑞尔和马克·沃尔伯格等人联合主演的好莱坞动作喜剧片《二流警探》发布了一批最新的拍摄剧照，影片由执导过《王牌播报员》的亚当·麦凯担任导演。 \n从主演人选上能够多少感受到本片在动作场景上的一些端倪，影片讲述的是关于警局中“二流警探”的一些奇闻趣事，而威尔·法瑞尔此次再次与导演亚当合作，不知能否碰撞出新的火花。 \n经历《半职业选手》和《失落之地》失利的威尔·法莱尔并不弃气馁，本片就与合作过《王牌播音员》、《塔拉迪加之夜》以及《非亲兄弟》的导演亚当·麦凯再度携手，并且拉上了猛男沃尔伯格。沃尔伯格虽说近年挂牌主演运气不比法莱尔好，但与人搭伙却留下过《夺金三王》、《无间行者》以及《我爱哈克比》中精彩的喜剧演技，此番与法莱尔不知能擦出怎样火花。 \n影片片方此次放出的是某个动作场景的拍摄剧照，不过场面算不得“壮观”，不知道在搞笑方面影片会给我们带来些什么新鲜的东西。</p><p><br/></p><h3>　　电影影评</h3><h5>　　《二流警探》观后感(一)：可能口味不对。。。。</h5><p>　　已经知道是搞笑片了。</p><p>　　但还是受不了那些对白，感觉和看二流小说一样。充斥那种黄色暴力。</p><p>　　我觉得剧情上也安排的很离谱，感觉不怎么地。一开始两个警察的激情演出只是让我想到了过去动作片中老套的警察追歹徒或者追踪。</p><p>　　而且在飞车奔向歹徒时那个时间轴和说的话，只有两个字“矫情”。 \n整体来讲我只是对那句“只有脚踏实地的老实人，即二流人物才是真正的英雄”这句可能有哲理。然而这个却不是本部电影的评价。因为片中两个警察却是想逞英雄来成功的。</p><p>　　总体来说。看的很颓废。也许是口味不对吧。</p><p>　　然后中间一段评价“电子情书”的对话我很愤怒，因为“电子情书”只是单纯地讲一段喜剧爱情故事，但他们竟然把主题放在了汉克斯的屁股上的痔疮。难以接受</p><p><br/></p><h5>　　《二流警探》观后感(二)：《二流警探》：一流搭档</h5><p>　　必须承认，我的确是受了NPR Fresh Air栏目影评人David Edelstein的影响才去看《二流警探》(The Other \nGuys)的。Edelstein对导演Adam McKay和演员Will Ferrell的黄金搭档颇为赞赏，尤其是二人合作的《两兄弟》(Step \nBrothers)，被他高度赞扬为“这十年来的最佳美国闹剧喜剧”。这“最佳”一说虽很值得商榷，但这两人合作能爆发出绚烂的喜剧火花则的确不假，就连我这个不怎么喜欢Will \nFerrell老小孩套路的观众都在影院里哈哈大笑，感叹不虚此行。</p><p>　　在《二流警探》中，Will \nFerrell的角色阿伦是个警局文书，不仅被那些叱咤风云的硬汉英雄警探们瞧不起，还得天天帮他们处理烂七八糟的报告文件。书呆子阿伦对自己的处境无任何不满，极度风险规避的他倒乐得能够在最安全的地方上班，并完全不用亲自面对任何危险阵仗。阿伦对面的同事特里可受不了了，Mark \nWahlberg饰演的这个降职警探一直都希望能找到个什么抛头露脸的机会，离开无聊的文职工作，重新成为一名“真正的警察”。</p><p>　　电影让Will Ferrell跟Mark Wahlberg搭配先就成功了一半。Will Ferrell不动声色的书呆子气和Mark \nWahlberg气急败坏的暴跳如雷放在一起实在是太有喜剧效果了，尤其在一场警局吵架戏中，这二人的气质对比更是达到了极点——特里不满阿伦每天喜滋滋地干无聊的文书工作，说自己要是只狮子，阿伦就是只可怜的金枪鱼，狮子跳进海里把金枪鱼吃掉!发泄完了的特里怎么也没想到阿伦不买他的帐，竟反过来给他分析了一大通什么狮子生活在非洲大陆不会游泳，而金枪鱼是深海强鱼之类的理论，滔滔不绝到最后，阿伦越说越高兴，说自己和自己的金枪鱼朋友们会发明一种陆上呼吸机，戴着出水、上岸，直到最后把狮子特里干掉。Mark \nWahlberg目瞪口呆的表情实在太好玩了，比他在《约会之夜》(Date Night)中的表现还要精彩，我看这家伙其实也很有喜剧天分嘛。</p><p>　　片中这样的爆笑场景还有很多，比如特里花痴阿伦的老婆，二人的上司在商场兼职售货，阿伦与特里频频受贿而不自知等，除了让人笑，也颇具社会讽刺意味，秉承了SNL一针见血的荧幕传统(导演Adam \nMcKay曾任SNL \n1995～2001年的剧本作者兼导演)。但比较《二流警探》和其他的类型喜剧，我觉得最为不同的一点是电影开头与结尾的动作戏竟也颇有看点，并没因搞笑的目的而粗制滥造，有种令人意外的振奋。导演Adam \nMcKay在采访中也强调了电影拍摄过程中对动作场景的重视，虽然资金有限，同一辆车左面撞扁了接着用，只拍右面，但要使滑稽模仿的滑稽性体现出来，这些动作场景也必须足够“好莱坞”才行。除此之外，Samuel \nJackson和Dwayne Johnson的客串也至关重要，要是没这俩人给“一流”界定出夸张的概念，后面的“二流”对比就不那么爆笑了。</p><p>　　尽管《二流警探》娱乐性十足，我还是觉得电影的情节大框架太过牵强，尤其结尾加上的美国CEO不合理高收入的统计数据，有见风使舵之嫌，不够真诚。实际上， \nAdam McKay的长项一直都还是SNL类型的讽刺小品，他和Will \nFerrell合作的最佳成果应该是2004年的电影《王牌播音员》(Anchorman：The Legend of Ron \nBurgundy)，而上一部的《两兄弟》励志故事本身在我看来则完全失败，根本不足以在一个半小时内给剧情和人物一个明确可信的演变方向，结果便马虎凑数了事。《二流警探》当然好出很多，但故事主线依然不如Will \nFerrell跟Mark Wahlberg两个的逗趣打嘴仗段子精彩。作为一部完整的喜剧电影，这怎么说都有点遗憾。</p><p><br/></p><h5>　　《二流警探》观后感(三)：No one gonna care。</h5><p>　　這是一部典型噠小人物做主角噠電影。</p><p>　　剛開始有Rock Johnson和那個特有名噠黑人我就知道主角不是他們倆。</p><p>　　因為太有英雄范児叻一個小時四十分鐘根本講不完。</p><p>　　果然這倆白癡跳樓死叻。</p><p>　　我其實沒甚嚒話想說。</p><p>　　這個故事也看得不是那麼明明白白眞眞切切噠。</p><p>　　腦袋裏就記得有那麼輛紅色噠車大街小巷噠穿梭。</p><p>　　我想。</p><p>　　有人天生就是愛出風頭就是英雄。</p><p>　　有人天生就祇能默默無聞。</p><p>　　但是小人物也能當英雄。</p><p>　　也有拋頭露面噠那一天。</p><p>　　不是嚒。</p><p>　　努力像那些嘲笑過妳噠人證明自己吧。</p><p>　　哪怕跌倒叻無數次。</p><p>　　證明他們噠嘲笑是多麼噠傻逼。</p><p>　　也許現在像小草一樣根本沒人在乎。</p><p>　　誰說以後不會像牡丹一樣花開時節動京城。</p><p><br/></p><h5>　　《二流警探》观后感(四)：《二流警探》：两位贱男擦出的火花</h5><p>　　为什么威尔·法瑞尔一定要演贱男才大卖，为什么马克·沃尔伯格近些年的贱男角色也越来越多了，当两个贱男排在一起，贼神马的都是浮云鸟~~</p><p>　　注意，他们虽然扮演的是贱男警察，但并非无能，各自都有所擅长的。要想当模范警察，不是撞个大运那么简单，尤其这个案子背后错综复杂，还惊动了上层。哪怕事实摆在那里，还送到了证监会，依然不在他们掌握之中。如此巨额的资金流动，没有这么多关卡保证，一个银行职员敲个键盘OK，这钱就出去啦?搞笑呢!所以说，两个贱男探案，运气很重要，但自身实力才是基础。</p><p>　　威尔·法瑞尔的角色真的很让男人们无语，人长得糟糟的，又没有幽默感，却总能得到辣女的青睐。影片中搞笑段子非常多，但有些冷幽默还真需要转下脑子才能看懂，每每看到威尔傻乎乎的较真段子里的某个词语时，才真的忍俊不禁了。</p><p>　　其实影片是有揭露一些金融系统的黑幕交易，这个案件本身并不复杂，但是涉及到银行、金融公司、基金，甚至海外投资，往往会得到保护。于是，各种钱财进了少数人的腰包，留下的是一地鸡毛，血本无归的投资者。就像结束时候的字幕，一个个数据都在揭露这个行业的内幕，此时倒是有点像迈克尔·摩尔的纪录片了。</p><p><br/></p><h5>　　《二流警探》观后感(五)：二流警探 (The Other Guys) 幕后英雄</h5><p>　　当最好的人选抽不出空的时候，就是幕后英雄挺身出来的时候了!</p><p>　　观罢此片，实在说不上什么喜爱之处，没有强壮的英雄出来展现完美的肌肉;没有热辣的女明星出来搔首弄姿;也没有火爆刺激的大场面;影片逻辑也牵强赴会，剧情更是乱七八糟...</p><p>　　可能是我的个人喜好问题，本该是一部幽默搞笑的电影，但是看着播放器上的时间轴由开始到结束，我愣是找不到什么发笑之处。虽然电影里面人来人往，热闹非凡...我这边却是看得哑口无言(想象一个人对着屏幕略微张口的白痴表情吧)。</p><p>　　电影终结，旁白终于出来讲了此片的真谛所在(不讲还真不知道它想说什么)：每个人都想成为家传户晓，众人崇拜的大英雄，但有时候真正做事，起到重要作用的却往往只是幕后的小人物。嗯..没错，世界就是如此，往往你看到各个高官、企业CEO在台上滔滔不绝发表自己的宏图伟略，真知灼见，先进产品时候，会知道在他们的背后有多少幕后的真英雄付出的心血。</p><p>　　我们在每天加班加点的工作，为什么?是因为他们在盛大华丽的发表会上公布了新的产品。这就是我们的现状，我们因此获得了微薄的加班费，加上他们在发表会上可能曾经或许说到过的“得益于大家员工的努力工作”。而我们就成为了企业发展征途上“必不可少”的炮灰;成为了商业机器资本获取中默默无闻的一颗螺钉，最后任其生锈腐朽。</p><p>　　似乎自己悲观了点，或者我们应该期待如同电影中的2位默默无闻的主角最后翻身成为红人吧?</p><p>　　: \n电影最后CAST的过程中，介绍了一种经典的投资公司骗局模式：庞氏骗局。我这边也简单介绍一下吧，旁氏骗局就是一种空手套白狼的手法，基本上就是捏造一种回报率很高的投资项目，吸引各种人来进行投资。在初期，他们会报以很高的利息，让人觉得有利可图，然后一层层地介绍更多客人投资钱进去，然后把后来的资金变成了前期投资者的利息。当最后投资者数量减少，新增资金不足以补偿之前投资者的利息时，这个金字塔就会崩塌，然后可能就是老板走人，客人血本无归的结果了。</p><p><br/></p><h5>　　《二流警探》观后感(六)：又见黄金假</h5><p>　　这der电影摆明了就是让你绞尽脑汁也猜不出一点政治企图的快餐消费品，就连本君老套的愤世嫉俗也全无用武之地。靠着贬值的美元堆积起来的大场面，与张氏烂片一贯的烧钱文艺路线不谋而合。苦撑的笑点令身为观众的你我除了给点同情的强颜欢笑，我想再没有其他任何言辞来修饰了。这是一个导演东拼西凑起来的大杂烩，好莱坞喜剧的种种桥段你都能在此电影中窥得一斑。不疼不痒的对白加上往里砸的真金白银，高楼大厦、凯迪拉克、直升机还有艾伦老婆的大胸脯，我真怀疑本片导演被张大仙灵魂附体了。不过此人比张大仙略胜一筹的是他没有表现出十足的仙风道骨，他倒是能从“人性”出发，起码这片子是个人都能看的懂，能勉强戴一顶美式喜剧的帽子吧。可是我纠结的是导演既然要拍喜剧为什么选择这俩宝贝儿主演，他们应该去演《七宗罪》之流的悬疑片。</p><p>　　首先特里的扮演者沃尔伯格，他这俨然党校出身的尊容气质能够唤起笑点才怪。一招一式虽说是个练家子，依然掩不住骨子里的书生气。眉宇间的男秘书气质，为什么不加入天朝建国大业的明星阵容中来呢。演员已然选错，导演却一错再错，情节充满了无厘头但丝毫不搞笑，甚至一些情节之间的连接没有丝毫的逻辑性，导演在黔驴技穷般地声嘶力竭。尤为让人不理解的是特里在舞房跟他马子对骂那一段，端地让我想到了国内家庭情感大剧《不要跟陌生人说话》里的安嘉和……艾伦白痴也就算了，当我看到特里那睿智的眼神，我真希望他能够把这傻角色演的大智若愚一些，他实在是装傻，这种演技反倒显得矫揉造作了。但是片中也不乏灵光一现的神来之笔，诸如“我选修过现代艺术，为了取笑周围搞现代艺术的人”这类台词，大仙、凯歌导演之徒统统秒杀~~~~~~</p><p>　　最让人无语的就是艾伦了，论长相没有特里的爱国;论演技还不如他那酱油丈母娘一半好。可导演偏偏给他安排一个肥差，对象跟情人加之反面角色巴西女郎无论谁看了都小心思澎湃，这小子还跟这儿假正经，美国导演的水平还真不如国内文艺工作者那两下子，至少咱们都是懂事儿的，只是咱们都装的不懂事儿而已。艾伦能耐就能耐在即使在局子里受尽同僚的苛责，即使特里把自己贬的娘气十足，即使自己的普锐斯被百般调戏，即使被上司降职去当城管，依然面不改色心不跳，任劳任怨。相比之下，国内的愤青和文艺青年是否应该自惭形秽呢?然而，影片本以美国标准大片开头却发展到N多但凡正常人思维真的不能理解的混蛋逻辑中来了：特里念错艾伦前女友的名字即被狂喷，而他前女友的老公却贱到追着赶着让艾伦上他老婆。如此这般污蔑人民智商的电影，试问导演是何肺腑?</p><p>　　电影最后的cast都已经完了，还装逼似的弄个说实话我真没看懂啥意思的片尾花絮“电影太假了”(大约51分钟左右的台词)，得了，洗洗睡吧……</p><p><br/></p><h5>　　《二流警探》观后感(七)：二流喜剧</h5><p>　　本片在美国的票房和评价都不错，但看过后基本没有惊喜：前十分钟你会觉得这是部动作大片，但不是的，如果那样得投多少钱啊;前二十分钟你会觉得本片的主角是塞缪尔·杰克逊和道恩·强森，但是你错了，这俩哥们血性太大自杀了;接下来片子就趋于平淡了。</p><p>　　实际上本片的笑点很低，给我印象最深的只有两处：一是 \n马克·沃尔伯格上了威尔·法瑞尔的红色小车后问这是什么车?法瑞尔答是丰田普鲁斯，沃尔伯格说象坐进了阴道(美国警察的车多为福特和通用的大型车);二是沃尔伯格在和法瑞尔夫妇告别时只与法瑞尔漂亮性感的妻子告别而不理法瑞尔，可法瑞尔还一遍遍与沃尔伯格说再见。</p><p>　　我一直不喜欢威尔·法瑞尔，他的电影也只看了《家有仙妻》和《非亲兄弟》，他总想板着脸表现出一种冷幽默，但事与愿违，一点也不搞笑。</p><p>　　真正吸引我看本片是因为沃尔伯格，这位老兄的《不羁夜》《万夫莫敌》《人猿星球》《偷天换日》等片表现出色，但最喜欢的还是他的《狙击手》这部动作片，之后又有了《我们拥有夜晚》《马克思佩恩》，老演员又有了第二春，期待他再有好作品。</p><p>　　本片D9中收录了两个版本：剧场版和延展版，分别为107分钟和116分钟，先选择延展版，看过后觉得一般就没看剧场版，直接看了删剪片断和花絮完事，要说明的是一区的D9内容还是比较丰富的，没抽条。</p><p><br/></p><h5>　　《二流警探》观后感(八)：《二流警探》：“窝囊废”也有春天</h5><p>　　《二流警探》在北美票房飘红，首周取得了1350万的骄人战绩，以致于将雄霸榜首的神作《盗梦空间》一举拿下。如何夺目的耀眼光辉，跟它的整体构架、流程、套路是密不可分的。可以说，这是一部很有诚意，且极力迎合北美观众口味的休闲爆米花影片。人致贱则无敌，将俗套的搞笑大量拼凑堆积，一路高歌猛进地癫狂到最后。除了肚子笑痛，大腿拍麻之外，剩下就是些经不起玩味的所谓的剧情，这就跟前段时间布鲁斯•威利斯的《拍档侦探》貌合神离了。同样都是展现“模范贱兄弟”奇闻异事的拼盘喜剧，但为什么前者摇身一变成了黑马，而后者却老老实实地自甘平庸呢?关于这个疑问的解释，完完全全都要归咎于投资，资金一到位，很大程度而言就已经事半功倍。接下去，就看导演怎么用这笔钱来耍宝了。</p><p>　　名不见经传的导演亚当•麦凯，出手极其犀利，在影片伊始就跟观众开了一个天大的玩笑。道格•强森、塞缪尔•杰克逊两大狂野彪悍的猛男强强联手，一路风驰电掣，所到一处顿时一片狼藉，如此高调拉风的追车场面在一般靠会话为主打元素的喜剧电影里实为少见。当Cop不再是Pig，而是Hero的时候，影片的反讽基调就全面铺开了。因此，由他俩这样的“一流警探”也顺其自然地引出了两位真正的主角“二流警探”，个人称他们为“窝囊废”。令人垂涎三尺的诱饵，在一次模仿“狼牙山五壮士”，惊天动地的壮举中戛然而止，简直是匪夷所思。对于这样华丽而莫名其妙的开篇，引起了很多影迷的怨声载道，其实细想一下，大可不必抱怨，一种吊人胃口的伎俩而已。只不过这一次，手段更高端，出手更阔气。再进一层次，成也开篇，败也开篇。</p><p>　　叱咤风云，威风一时的“一流警探”英勇就义之后，是时候该让那两个窝囊废粉墨登场了。由马克•沃尔伯格饰演的Terry是个壮志未酬，不甘心寄于他人屋檐之下的警探，整天宅在警局里从事娘娘腔的文秘工作，让他恍恍而不可终日。用他自己的话来说，他是一只渴望飞翔的孔雀，至于孔雀到底能不能飞，这个还有待商榷。要是说Terry还尚存一丝纯爷们气息的话，那他的拍档Allen就是彻头彻尾的“伪娘”了。影片的前一大段，都不遗余力地在展现Allen自甘卑微，低声下气，而从来不考虑有关于出人头地的一切。在他的人生格言里，似乎“安逸、稳定”才是本真，“冒险、刺激”什么的都是浮云。性感女神伊娃•门德斯友情客串娇妻，又使得影片将讽刺的意味推向高潮。平庸背后的光鲜，如此纯粹虚幻的对比令人瞠目结舌，这又是营造观影氛围的一种聪明的手法。电影不是生活，生活比电影苦;同样的，生活不是电影，电影比生活更美好。想必，“窝囊废”们的春天，都在电影里。</p><p>　　影片走的还是关于资本投资失败，为掩盖填补亏损，而妄图破釜沉舟的老套路。可圈可点的是，喜剧桥段的拼接与堆砌，配搭上演员完美的演技，也颇具喜感与看点。“FBI”——Female \nBody \nInspector，管他恶不恶俗，一切为了搞笑而服务;酒吧疯狂到极致的静态场面，带着明显模仿《宿醉》的痕迹;用高尔夫球来打飞机，虽转瞬即逝，也让人印象深刻;通过老妈来传达床第之欢的情趣，言辞之激烈，堪比兵刃刺进胸膛，个人表示毫无压力。诸多举不胜举的恶趣味，由此可见导演下笔的重心所在。值得一提的是，原本平铺直述的叙事路线，还了来了一次大转折。Allen的“人格分裂”，让他不愧对于纯爷们的称号，而向来冲动鲁莽的Terry此时又转型成了安逸守旧派。虽说这个戏剧矛盾冲突很短暂，但也无形地给原本单薄无力的剧情增添了一点活力。像这样微小的旁枝末节，导演做得相当到位，让整部影片的信息量一点点膨胀。当然了，有用没用还得另当别论，无非是更高层次的消遣罢了。</p><p>　　画外音的加入，很复古也很唐突，在剧情存在断层不能自圆其说的时候派上用场。这也说明，倘若影片在剧情主线上再加以雕琢润色，那么呈现在观众面前的作品将更加丰满。《二流警探》的成功，给日渐平庸没落的好莱坞传统喜剧套路电影，扎扎实实地上了一课。舍不得孩子，套不着狼，当疯狂地将资金砸在看似毫无意义的火爆场面上，也许票房的“春天”就在不远处。</p><p><br/></p><h5>　　《二流警探》观后感(九)：二流的大多数。有什么比二流更重要。</h5><p>　　没得二流哪来的一流?一流也不是从二流过来的。</p><p>　　当道恩·强森和塞缪尔·杰克逊这两个具有鲜明特点的脸出现。一流的脸，一流的个性的警察角色。秒杀众人。</p><p>　　疯狂的追车，可以用跑就绝不用走，可以开车就绝不打的的奢华路线。</p><p>　　什么是一流。一流就是从开头到结尾都得完美，炫目。</p><p>　　当然，为了让二流上位，一流死的时候那可谓是剑走偏锋。</p><p>　　他们都是职业的。怎么办。看准那个灌木丛了么?let&#39;s go。华丽，就是与众不同，一流不用绳索，哪怕是二十层楼。</p><p>　　而且，一流。不用。俗套的“救命稻草”。</p><p>　　好了。一流总有退居二线的时候，青出于绿而胜于蓝。</p><p>　　威尔· 法瑞尔和马克·沃尔伯格两个二。二流。</p><p>　　要不是看过《完美风暴》《生死狙击》根本不认得马克·沃尔伯格。我不熟悉马克·沃尔伯格正如我不熟悉威尔· 法瑞尔。</p><p>　　不过作为二流，作为大众，他们太出色。有点厚积薄发的意思。个个先低调吧不低调就太低调的风格。</p><p>　　我是二流你就以为我真的是“二流”嘛。</p><p>　　学个芭蕾舞只是为了讽刺别人，学过艺术就是用来取笑伪艺术。</p><p>　　一脸憨厚老实的样子，却有着so hot的老婆，还有更让人费解的美丽EX，以及曾经是皮条客的辉煌记录。</p><p>　　你以为的二流都是他们的一部分而已。</p><p>　　社会中有太多的二流藏在身边，而只是因为人们的眼中充满了所谓的一流。</p><p>　　一流的都是来自于人们的恶捧。以及部分人的主观肯定。而这些不晓得什么时候变成了代表了大多数的看法，一流应运而生。</p><p>　　当然这里的一流二流是指的等级。优和良的区别。而不是“三教九流”上中下二十七流的关系地位。</p><p>　　一流二流的界定标准都是你定的，凭什么你要看扁二流。</p><p>　　所以什么男女平等。众生平等。之类已然成为空谈。</p><p>　　社会越进步，界定越来越多，谁的小众，谁的主流。</p><p>　　有谁被二流。</p><p>　　相信吧。你我都是二流。</p><p>　　你可以选择做二流的中流砥柱，或者是积极地变成一流。</p><p>　　取决于你想要成为鸡头还是凤尾。</p><p>　　送给自己。</p><p>　　还真别不平衡。农民都能当艺术家你还真就当不上，不是说人家绝对的土鳖，哪怕是相对于你的土鳖，别人全家都艺术家了，还是没你的份。</p><p>　　2b当领导也别抱怨，哪怕他什么都不会，全世界都能领导你了，你也就只有被领导的份儿。</p><p>　　没办法，一个音几个字，粪，愤。</p><p>　　而且还，不奋。</p><p>　　啃老都是恩惠。</p><p><br/></p><h5>　　《二流警探》观后感(十)：Funny or die? Funny!</h5><p>　　我很佩服Peter Bradshaw(《卫报》知名影评人)在自己的满分评价并没有得到太多读者认同的情形下，将Adam McKay的《二流警探》(The \nOther \nGuys)放进了自己的年度十佳，并且宣称唯一的遗憾是没有办法给这部影片再加1到2颗星。即使在美国本土,这部影片虽然获得商业成功，却也并未得到如此般的推崇。我想，这也许是人们对于“闹喜剧”的偏见，全世界每年出产如此多的闹剧，真正能让人放声大笑的并不多，能让人从头至尾笑得酣畅淋漓，又能获得情感上的欢娱，不用背上什么道德包袱，还能欣赏其幽默设置的更少之又少，本片便是其中之一。我第一次观看这部影片的时候，是看着连猜带蒙一塌糊涂的字幕，不少剧情都没有梳理清晰的情况下，依然不由得为其惊人的喜剧魅力而吸引。</p><p>　　影片的男主角之一Mark Wahlberg似乎没见他演过喜剧，这次跟Will \nFerrell搭档，出演一对关系微妙的警局搭档，竭力“正常化”的表演和Terry这个凡事认真(什么样的人会为了嘲笑gay而学跳芭蕾舞!)却总遭打击的小人物却是颇为合拍，再加上绝大多数时刻都处于脱线状态的Allen，本片的成功，跟他们之间迷人的化学反应分不开。而且Adam \nMcKay的各种笑话段子，不止密集(几乎不放过一秒填充笑料的空间)，信息量庞大，往往还有点冷幽默的范儿，前呼后应，经得起再三回味。片中一个显著的喜剧因素，是着力制造的“反差”印象。两位“二流警探”的上司，居然在超市里兼职售货员挣钱(Michael \nKeaton的出演亦是本片的诸多亮点之一 )。片头由Dwayne Johnson和Samuel L. \nJackson所饰的两位“一流警探”上演完火爆追车戏码后，居然双双自杀。还有二人的葬礼之上，一群警察们却在这个庄重的场合偷偷干起架，尤其是联想葬礼本身的讽刺意味，这一个场景真是拍得让人好气又好笑。</p><p>　　当然，尽管本片中各种角色身上都有无穷笑点爆出，大部分的重心还是压在Ferrell的肩上，在故事的开场，Allen这个角色好像是现实中一个很平凡的loser，Ferrell对其的刻画就给我留下了深刻的印象，他活在自己世界内自得其乐，既没有令人厌恶，也从不试图讨取观众的同情。更为难得的是，随着剧情的发展，这个角色不断的被赋予各种新的层面，极尽荒诞与癫狂，Ferrell依然能牢牢把握住搞笑表演与浮夸做作之间的尺度，在他的演绎下，这个人物设置近乎匪夷所思的家伙，却不曾远离与观众情绪之间的距离。另一方面，Adam \nMcKay在笑话轰炸的同时也没有忘记叙事，同时还不时上演了不少动作场面，作为搞笑之后的餐后甜点，倒也娱乐性十足。如果你想寻找一部能尽情释放笑声的影片，如果你问我的看法，《二流警探》可能是今年最好的一部。</p><p><br/></p>', 'public', 'true', 0, 5);

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cid` int(10) NOT NULL AUTO_INCREMENT COMMENT '分类的id',
  `cpid` int(10) NOT NULL DEFAULT '0' COMMENT '分类的父类id',
  `categoryname` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '分类的名称',
  `categoryyw` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '分类的英文',
  `categoryms` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '分类的注析',
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`cid`, `cpid`, `categoryname`, `categoryyw`, `categoryms`) VALUES
(6, 0, '电影', 'cinema', '收集短视频，电影解说'),
(7, 6, '解说影评', 'cinema_commentary', '收集各类up主针对电影做出的解说，影评，吐槽等');

-- --------------------------------------------------------

--
-- 表的结构 `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `cmid` int(11) NOT NULL AUTO_INCREMENT COMMENT '评论的id',
  `cmpid` int(11) NOT NULL COMMENT '评论的父id',
  `cmtid` int(11) NOT NULL COMMENT '对于的文章id',
  `cm_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT '评论的用户名称',
  `cm_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '评论的用户的邮箱',
  `cm_web` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '评论的用户的网址',
  `cm_sh` tinyint(4) NOT NULL DEFAULT '1' COMMENT '评论是否通过审核',
  `cm_dz` int(11) NOT NULL DEFAULT '0' COMMENT '评论的点赞数',
  `cm_comment` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '评论的内容',
  PRIMARY KEY (`cmid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- 表的结构 `curl_article`
--

CREATE TABLE IF NOT EXISTS `curl_article` (
  `caid` int(11) NOT NULL AUTO_INCREMENT COMMENT '获取文章的id',
  `curl_title` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '采集文章的标题',
  `curl_container` text COLLATE utf8_unicode_ci NOT NULL COMMENT '采集文章的内容',
  `curl_category` int(11) NOT NULL COMMENT '存放栏目的id',
  `curl_source` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '文章的来源',
  `curl_html` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '文章来源的网址',
  PRIMARY KEY (`caid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- 表的结构 `friend_link`
--

CREATE TABLE IF NOT EXISTS `friend_link` (
  `fid` int(11) NOT NULL AUTO_INCREMENT COMMENT ' 友情链接的id',
  `ftitle` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '友情链接的名称',
  `flink` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '友情链接的链接',
  `fintroduction` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '友情链接的描述',
  `fdate` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '友情链接的添加时间',
  `ftype` tinyint(4) NOT NULL DEFAULT '0' COMMENT '友情链接的类型',
  `fimage` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '友情链接的存储名称',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- 表的结构 `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '成员Id',
  `iid` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '成员编号',
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '成员用户名',
  `password` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '登录密码',
  `the_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户的中文账号名',
  `sex` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户的性别',
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户email',
  `tel` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户的电话号码',
  `join_time` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户加入时间',
  `role` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'edit',
  `user_head` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户的头像',
  `user_img` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户的封面',
  `city` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户的城市',
  `user_introduction` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户的介绍',
  `session_token` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户的session_token',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `member`
--

INSERT INTO `member` (`id`, `iid`, `username`, `password`, `the_name`, `sex`, `email`, `tel`, `join_time`, `role`, `user_head`, `user_img`, `city`, `user_introduction`, `session_token`) VALUES
(1, '11', 'admin', 'zzz7750260', '', '', '', '0', '', 'admin', '', '', '', '', '20180823085703UuoNVhI1'),
(17, '201808230843311684', 'bigsmile', 'bigsmile', 'big笑工坊', '男', '2301595053@qq.com', '1651620320', '2018-08-23 08:43:31', 'edit', '1705221243c539c990af999ff81d8bc78fdcfe2e26.jpg', '', '广州', 'big笑工坊是由微信号：任真天 所建，以电影解说，生活吐槽等视频为主，解说风格幽默风趣', '20180826032905Nxkkmqxj');

-- --------------------------------------------------------

--
-- 表的结构 `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `mid` int(10) NOT NULL AUTO_INCREMENT COMMENT '菜单的id',
  `mpid` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT '菜单的父类id',
  `menuname` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '菜单的名称',
  `menurole` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'admin' COMMENT '菜单的权限',
  `menuyw` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '菜单的英文',
  `menuurl` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '菜单的链接',
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- 表的结构 `page`
--

CREATE TABLE IF NOT EXISTS `page` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '封面的id',
  `ptitle` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '封面的名称',
  `title_yw` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '封面的英文名称',
  `author` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT '封面的作者',
  `cover_img` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '封面的图片',
  `cover_introduction` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '封面的介绍',
  `cover_time` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT '封面的传建时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `page`
--

INSERT INTO `page` (`pid`, `ptitle`, `title_yw`, `author`, `cover_img`, `cover_introduction`, `cover_time`) VALUES
(13, '唐唐说电影', 'tangtangspeak', 'bigsmile', '05160000598047FCAD881A032D003617.jpg', '《唐唐说电影》是一档搞笑的电影解说类节目。唐唐辣评热门时鲜，经典冷门电影，脑洞大开让你乐不停。', '2018-08-23 08:50:29');

-- --------------------------------------------------------

--
-- 表的结构 `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `rid` int(3) NOT NULL AUTO_INCREMENT COMMENT '角色的id号',
  `rolename` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '角色名称',
  `roleyw` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '角色英文名称',
  `rolems` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '角色描述',
  `rolelmqx` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '角色栏目管理权限',
  `rolewzqx` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章管理权限',
  `roleyhqx` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户管理权限',
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- 表的结构 `web_info`
--

CREATE TABLE IF NOT EXISTS `web_info` (
  `web_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '网站的名称',
  `web_title` varchar(300) COLLATE utf8_unicode_ci NOT NULL COMMENT '网站的title',
  `web_keyword` varchar(300) COLLATE utf8_unicode_ci NOT NULL COMMENT '网站的关键词',
  `web_short` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '网站的描述',
  `web_author` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '网站的作者',
  `web_record` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '网站的备案号',
  PRIMARY KEY (`web_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `web_info`
--

INSERT INTO `web_info` (`web_name`, `web_title`, `web_keyword`, `web_short`, `web_author`, `web_record`) VALUES
('课间十分钟', '热门短视频|微电影分享平台', '微电影,短视频,搞笑视频,美食视频,教育视频,生活常识,健康知识,课间十分钟', '课间十分钟是一个以短视频，微电影为主的视频分享网站，主要分电影视频，生活常识视频，搞笑视频，美食视频，健康视频，教育视频等多个频道，视频来源只要为网络，希望课间十分钟能在大家生活空闲的片刻，带给大家欢乐，知识，感悟', 'admin', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
