-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018-11-08 08:55:35
-- 服务器版本: 5.5.56-MariaDB
-- PHP 版本: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `myprogram`
--

-- --------------------------------------------------------

--
-- 表的结构 `FM`
--

CREATE TABLE IF NOT EXISTS `FM` (
  `fid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'FM的id',
  `fm_category` int(11) NOT NULL COMMENT 'FM所属的分类',
  `f_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FM的名称',
  `f_keyword` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FM的关键词',
  `f_img` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FM文章的配图',
  `f_admin` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FM的作者',
  `f_short` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FM的描述',
  `f_time` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FM的日期',
  `f_container` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FM的内容',
  `f_fm` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FM的文件',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `FM`
--

INSERT INTO `FM` (`fid`, `fm_category`, `f_title`, `f_keyword`, `f_img`, `f_admin`, `f_short`, `f_time`, `f_container`, `f_fm`) VALUES
(1, 0, '测试FM', 'FM', '20181011112002.jpg', 'admin', '测试FM测试FM测试FM', '2018-11-06 04:28:24', '<p>测试FM测试FM测试FM测试FM测试FM测试FM测试FM测试FM</p>', ''),
(2, 0, '测试FM11', 'FM', '20181011112002.jpg', 'admin', '测试FM测试FM测试FM', '2018-11-06 04:35:07', '<p>测试FM测试FM测试FM测试FM测试FM测试FM测试FM测试FM</p>', ''),
(3, 0, '测试FM11', 'FM', '20181011112002.jpg', 'admin', '测试FM测试FM测试FM', '2018-11-06 04:46:32', '<p>测试FM测试FM测试FM测试FM测试FM测试FM测试FM测试FM</p>', ''),
(4, 0, '测试FM11', 'FM', '20181011112002.jpg', 'admin', '测试FM测试FM测试FM', '2018-11-06 04:48:21', '<p>测试FM测试FM测试FM测试FM测试FM测试FM测试FM测试FM</p>', ''),
(5, 0, '测试FM11', 'FM', '20181011112002.jpg', 'admin', '测试FM测试FM测试FM', '2018-11-06 04:56:39', '<p>测试FM测试FM测试FM测试FM测试FM测试FM测试FM测试FM</p>', ''),
(6, 0, '测试FM11', 'FM', '20181011112002.jpg', 'admin', '测试FM测试FM测试FM', '2018-11-06 09:24:49', '<p>测试FM测试FM测试FM测试FM测试FM测试FM测试FM测试FM</p>', ''),
(7, 0, '测试FM11', 'FM', '20181011112002.jpg', 'admin', '测试FM测试FM测试FM', '2018-11-06 09:25:37', '<p>测试FM测试FM测试FM测试FM测试FM测试FM测试FM测试FM</p>', ''),
(8, 0, '测试FM11', 'FM', '20181011112002.jpg', 'admin', '测试FM测试FM测试FM', '2018-11-06 09:37:57', '<p>测试FM测试FM测试FM测试FM测试FM测试FM测试FM测试FM</p>', ''),
(9, 0, '', '', '', 'admin', '', '2018-11-06 09:42:29', '<p>啊上档次</p>', ''),
(10, 0, '测试呢', '测试呢', '20181012111813.jpg', 'admin', '测试呢测试呢测试呢', '2018-11-06 10:23:47', '<p>测试呢测试呢测试呢测试呢测试呢测试呢</p>', ''),
(11, 0, '测试呢', '测试呢', '20181012111813.jpg', 'admin', '测试呢测试呢测试呢', '2018-11-06 10:26:42', '<p>测试呢测试呢测试呢测试呢测试呢测试呢</p>', ''),
(12, 0, '测试呢', '测试呢', '20181012111813.jpg', 'admin', '测试呢测试呢测试呢', '2018-11-06 10:27:37', '<p>测试呢测试呢测试呢测试呢测试呢测试呢</p>', ''),
(13, 0, '测试呢啊啊', '测试呢', '2018101511233.jpg', 'admin', '测试呢测试呢测试呢', '2018-11-06 10:32:57', '<p>测试呢测试呢测试呢测试呢测试呢测试呢</p>', ''),
(14, 0, '测试呢啊啊', '测试呢', '20181010112005.jpg', 'admin', '测试呢测试呢测试呢', '2018-11-06 10:48:20', '<p>测试呢测试呢测试呢测试呢测试呢测试呢</p>', ''),
(15, 0, '测试呢啊啊11', '测试呢', '20181012111815.jpg', 'admin', '测试呢测试呢测试呢', '2018-11-06 11:00:34', '<p>测试呢测试呢测试呢测试呢测试呢测试呢</p>', 'Lemon Tree.mp3'),
(16, 0, '测试新', 'aS', '054101015B45DD588B7B44A4A05918D7.jpg', 'admin', '大市场', '2018-11-07 04:47:48', '<p>爱上大叉车</p>', 'Lemon Tree.mp3'),
(17, 0, '测试新相生相成', 'aS', '054101015B45DD588B7B44A4A05918D7.jpg', 'admin', '大市场', '2018-11-07 05:19:04', '<p>爱上大叉车</p>', 'qfdy.mp3');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
